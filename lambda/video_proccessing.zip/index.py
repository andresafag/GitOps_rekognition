import json
import boto3
import os

rekognition = boto3.client('rekognition')

def handler(event, context):
    print(f"Received event: {json.dumps(event)}")
    # 'event' contiene una lista de mensajes (Records)
    for record in event['Records']:
        # 1. Extraer el ID del mensaje (opcional, para logs)
        message_id = record['messageId']
        
        # 2. El contenido del mensaje está en 'body'
        # Generalmente viene como un string JSON, así que hay que parsearlo
        try:
            body = json.loads(record['body'])
            
            # Si vienes de Rekognition vía SNS -> SQS, 
            # el JobId estará dentro del campo 'Message'
            if 'Message' in body:
                sns_message = json.loads(body['Message'])
                job_id = sns_message.get('JobId')
                status = sns_message.get('Status')
                print(f"Procesando Job: {job_id} con estado: {status}")
            
            # Aquí iría tu lógica (ej. llamar a get_label_detection)
            all_labels = []
            next_token = None

            while True:
                # Configuración de la llamada
                params = {'JobId': job_id}
                if next_token:
                    params['NextToken'] = next_token

                # Llamada a la API
                response = rekognition.get_label_detection(**params)

                # Guardar resultados
                labels = response.get('Labels', [])
                all_labels.extend(labels)

                # for label_entry in labels:
                #     label = label_entry.get('Label', {})
                #     name = label.get('Name')
                #     confidence = label.get('Confidence')
                #     timestamp = label_entry.get('Timestamp')
                #     print(f"Label detected: {name} | Confidence: {confidence} | Timestamp: {timestamp}")

                # Verificar si hay más páginas de resultados
                next_token = response.get('NextToken')
                if not next_token:
                    break

            print(f"Total labels found: {len(all_labels)}")
            return {
                'statusCode': 200,
                'body': json.dumps({'labels': all_labels})
            }
        except Exception as e:
            print(f"Error procesando mensaje {message_id}: {str(e)}")
            # Si lanzas una excepción, el mensaje volverá a la cola SQS
            raise e

    return {
        'statusCode': 200,
        'body': 'Mensajes procesados'
    }    
    