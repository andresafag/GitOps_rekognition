import json
import boto3
import urllib.parse
import os
from datetime import datetime

rekognition = boto3.client('rekognition')
s3 = boto3.client('s3')
dynamoDB = boto3.resource('dynamodb')
table = dynamoDB.Table('mapping-routes')
connection_table = dynamoDB.Table('websocket-connections')
bucket = os.environ['IMAGE_BUCKET_NAME']

def handler(event, context):
    try:
        for record in event.get('Records', []):
            body = json.loads(record['body'])
        if 'Records' in body:
            for s3_record in body['Records']:
                try:
                    # 3. Accedemos a los datos de S3 correctamente
                    object_key = s3_record['s3']['object']['key']
                    bucket_name = s3_record['s3']['bucket']['name']

                    image = {
                        'S3Object': {
                        'Bucket': bucket,
                        'Name': object_key
                        }
                    }
                    
                    # 4. Obtenemos los metadatos
                    metadata = s3.head_object(Bucket=bucket_name, Key=object_key)
                    metadatos = metadata.get('Metadata', {})
                    print(f"Metadata for object {object_key}: {metadata.get('Metadata')}")
                    formatted = {
                        "mode": metadatos.get('detection_mode'),
                        "items": []
                    }

                    if metadatos.get('detection_mode') == 'labels':
                        result = rekognition.detect_labels(Image=image, MaxLabels=10, MinConfidence=75)
                        for item in result.get('Labels', []):
                            formatted["items"].append({
                                "name": item['Name'],
                                "confidence": round(item['Confidence'], 2)
                            })
                        print(rekognition.detect_moderation_labels(Image=image))
                    elif metadatos.get('detection_mode') == 'celebrity':
                        result = rekognition.recognize_celebrities(Image=image)
                        for item in result.get('CelebrityFaces', []):
                            formatted["items"].append({
                                "name": item['Name'],
                                "confidence": round(item['MatchConfidence'], 2),
                                "urls": item.get('Urls', [])
                            })
                    print(formatted)

                    mensaje=json.dumps({
                        "mensaje_servidor": "resultados",
                        "info": formatted
                    })

                    gatewayapi = boto3.client(
                        "apigatewaymanagementapi", 
                        endpoint_url=metadatos.get('domainname')
                    )

                    gatewayapi.post_to_connection(
                        ConnectionId=metadatos.get('connection_id'),
                        Data=mensaje  
                    )
                    
                except KeyError as e:
                    print(f"Error: No se encontró la clave {e} en el evento de S3")












        # elif body_data.get("detection_mode") == "celebrity":
        #     result = rekognition.recognize_celebrities(Image=image)
        #     print('Rekognition celebrity result:', json.dumps(result, indent=2, default=str))
        #     for item in result.get('CelebrityFaces', []):
        #         formatted["items"].append({
        #             "name": item['Name'],
        #             "confidence": round(item['MatchConfidence'], 2),
        #             "urls": item.get('Urls', [])
        #         })
        # final_result = formatted
        # print("Final formatted result to send via WebSocket:", final_result)
    except Exception as metadata_error:
        print(f'Could not read object metadata: {metadata_error}')




    # for record in event.get('Records', []):
    #     body = record.get('body')
    #     try:
    #         message = json.loads(body)
    #     except Exception as error:
    #         print('Unable to parse SQS record body', error)
    #         continue

    #     s3_records = message.get('Records', [])
    #     if not s3_records:
    #         print('Non-S3 event passed from SQS', message)
    #         connection_id = message['connectionId']
    #         domain_name = f"{message['domainName']}"
    #         stage = message['stage']
    #         endpoint_url = f"https://{domain_name}"
    #         continue

    #     s3_event = s3_records[0].get('s3')
    #     if not s3_event:
    #         print('Non-S3 event passed from SQS', message)
    #         continue

    #     bucket_name = s3_event['bucket']['name']
    #     object_key = urllib.parse.unquote_plus(s3_event['object']['key'])

    #     print('Processing object', bucket_name, object_key)
    #     print(f'Object key: {object_key}')
    #     detection_mode = 'labels'

    #     try:
    #         connection_id = {event.get('Records', [])}['connectionId']
    #         domain_name = {event.get('Records', [])}['domainName']
    #         stage = {event.get('Records', [])}['stage']
    #         endpoint_url = f"https://{domain_name}"
    #         gatewayapi = boto3.client(
    #             "apigatewaymanagementapi", 
    #             endpoint_url=f"https://nhbrtauvtg.execute-api.us-east-1.amazonaws.com/$default/@connections/{connection_id}"
    #         )
    #         print(f"Initialized API Gateway Management API client with endpoint: {endpoint_url}")
    #         metadata = s3.head_object(Bucket=bucket_name, Key=object_key).get('Metadata', {})
    #         detection_mode = metadata.get('detection-mode', detection_mode)
    #     except Exception as metadata_error:
    #         print(f'Could not read object metadata: {metadata_error}')

    #     if detection_mode not in ('labels', 'celebrity'):
    #         if object_key.startswith('uploads/celebrity/'):
    #             detection_mode = 'celebrity'
    #         else:
    #             detection_mode = 'labels'
    #     parte = event['Records'][0]
    #     body = json.loads(parte['body'])
    #     s3_info = body['Records'][0]['s3']['object']['key']
    
    # # 4. Extraes el key y lo decodificas (por si tiene espacios o caracteres especiales)
    #     # raw_key = s3_info['object']['key']

    #     parts = s3_info.split('/') # ['uploads', 'labels', '585f75c9...-woman.jpeg']
    #     extracted_id = parts[-1] 
    #     print(f'Extracted ID: {extracted_id} from object key: {object_key}')
    #     print(table.get_item(Key={'id': extracted_id}))
    #     response = table.get_item(Key={'id': extracted_id})

    #     print(response.get('Item'))
    #     item = response.get('Item')
    #     image = {
    #         'S3Object': {
    #             'Bucket': bucket_name,
    #             'Name': object_key
    #         }
    #     }
    
    #     if not item:
    #         return {"error": "Item not found in DynamoDB"}

    #     try:
    #         if detection_mode == 'celebrity':
    #             result = rekognition.recognize_celebrities(Image=image)
    #             print('Rekognition celebrity result:', json.dumps(result, indent=2, default=str))

    #             # result_data = {
    #             #     'originalImage': object_key,
    #             #     'timestamp': datetime.utcnow().isoformat(),
    #             #     'detectionMode': detection_mode,
    #             #     'celebrities': result.get('CelebrityFaces', []),
    #             #     'unrecognizedFaces': result.get('UnrecognizedFaces', []),
    #             #     'responseMetadata': result.get('ResponseMetadata', {})
    #             # }


    #         else:
    #             result = rekognition.detect_labels(Image=image, MaxLabels=10, MinConfidence=75)
    #             print('Rekognition label result:', json.dumps(result, indent=2, default=str))

    #             # result_data = {
    #             #     'originalImage': object_key,
    #             #     'timestamp': datetime.utcnow().isoformat(),
    #             #     'detectionMode': detection_mode,
    #             #     'labels': result.get('Labels', []),
    #             #     'responseMetadata': result.get('ResponseMetadata', {})
    #             # }
    #             print(f"Endpoint URL for WebSocket response: {endpoint_url}")
    #             gatewayapi.post_to_connection(
    #             ConnectionId=connection_id,
    #             Data=json.dumps({
    #                 "mensaje_servidor": json.dumps(result, indent=2, default=str),
    #                 "info": "Enviado desde el proceso SQS"
    #                 })
    #             )

    #         # result_key = f"results/{object_key.replace('/', '-')}.json"

    #         # print(f'Stored Rekognition results to dynamoDB for {object_key}')
    #         # file_name = object_key.split('/')[-1] 
    #         # raw_id = file_name.split('-')[0]  
    #         # image_id = int(raw_id)       

    #         # table.put_item(
    #         #     Item={
    #         #         'id': image_id,
    #         #         's3_key': object_key,
    #         #         'DetectionMode': {'S': detection_mode},
    #         #         'Timestamp': {'S': datetime.utcnow().isoformat()},
    #         #         'ResultKey': {'S': result_key},
    #         #         'ResultData': {'S': json.dumps(result_data, default=str)}
    #         #         }
    #         # )

    #     except Exception as error:
    #         print(f'Rekognition failed: {error}')
    #         # Store error information
    #         error_key = f"results/errors/{object_key.replace('/', '-')}.json"
    #         error_data = {
    #             'originalImage': object_key,
    #             'timestamp': datetime.utcnow().isoformat(),
    #             'error': str(error)
    #         }
    #         # try:
    #         #     table.put_item(
    #         #     Item={
    #         #         'id': image_id,
    #         #         's3_key': object_key,
    #         #         'DetectionMode': {'S': detection_mode},
    #         #         'Timestamp': {'S': datetime.utcnow().isoformat()},
    #         #         'ResultKey': {'S': result_key},
    #         #         'ResultData': {'S': json.dumps(result_data, default=str)}
    #         #         }
    #         # )
    #         #     print(f'Stored error {error_key}')
    #         # except Exception as s3_error:
    #         #     print(f'Failed to store error log: {s3_error}')

    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Processed SQS batch.'})
    }
